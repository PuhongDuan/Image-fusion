function [MLR_Probilities,RWOptimize_Probabilies] = SOASSL(varargin)

img = varargin{1}; % 1st parameter is the data set
s=img.s;    % �߹���ͼ�����Ϣ 145*145*200 16��
rows=s(1);
cols=s(2);
bands=s(3);
classes=s(4);
if ~numel(img),error('the data set is empty');end
train = varargin{2}; % the 2nd parameter is the training set
if isempty(train), error('the train data set is empty, please provide the training samples');end
no_classes = max(train(2,:));  % ���ࡱ�����ֵ

if nargin >2
    test = varargin{3}; % the 3rd parameter is the test
else
    fprintf('the test set is empty, thus we use the training set as the validation set \n')
    test = train;
end
if nargin >3
    AL_sampling = varargin{4};
else
    AL_sampling = [];
end

if isempty(AL_sampling)
    tot_sim = 1;
else
    tot_sim = AL_sampling.U/AL_sampling.u +1;  % 70/10 + 1 = 8;
end
if nargin >4
    no_sslsamples = varargin{5};
else
    no_sslsamples = 20;
end

train1=train;
% parameters
learning_method = 'RBF';
algorithm_parameters.lambda=0.001;
algorithm_parameters.beta = 0.5*algorithm_parameters.lambda;
% start active section iterations
%     fprintf('Active selection iteration  %d \n', iter);
      trainset = img.im(:,train(1,:));
%     trainset = img.source(:,train(1,:));       
    if strcmp(learning_method,'RBF')
        sigma = 0.8;        
        % build |x_i-x_j| matrix 
        nx = sum(trainset.^2);
        [X,Y] = meshgrid(nx);
        dist=X+Y-2*trainset'*trainset;
        clear X Y
        scale = mean(dist(:));
        % build design matrix (kernel) 
        K=exp(-dist/2/scale/sigma^2);
        clear dist
        % set first line to one 
        K = [ones(1,size(trainset,2)); K];
    else
        K =[ones(1,size(trainset,2)); trainset];
        scale = 0;
        sigma = 0;
    end
    
    learning_output = struct('scale',scale,'sigma',sigma);
    
    % learn the regressors
    [w,L] = LORSAL(K,train(2,:),algorithm_parameters.lambda,algorithm_parameters.beta);
    
    % compute the MLR probabilites
    p = mlr_probabilities(img.source,trainset,w,learning_output);   % ����ÿһ��ĸ��� 16*21025
    my_p1 = p(1,:);
    my_Probilities(1,img.boundary) = my_p1;
    my_Probilities(1,img.light) = 1;
    my_Probilities(1,img.dark) = 0;
        my_p1 = p(2,:);
    my_Probilities(2,img.boundary) = my_p1;
    my_Probilities(2,img.light) = 0;
    my_Probilities(2,img.dark) = 1;
%     p = mlr_probabilities(img.im,trainset,w,learning_output);   % ����ÿһ��ĸ��� 16*21025
    MLR_Probilities = reshape(my_Probilities(1,:),[rows cols]);
%     [maxp, class_results.map] = max(p); % ������������һ�� ��value �� index
%     %show the MLR classification map
%     MLRmap=class_results.map;           % �õ����ͼ�� 1~16
%     MLRmap=reshape(MLRmap,[rows cols]);
%    figure(1),imshow(MRFclassif);
%     [class_results.OA(iter),class_results.kappa(iter),class_results.AA(iter),...
%     class_results.CA(iter,:)]= calcError(test(2,:)-1, class_results.map(test(1,:))-1,[1:no_classes]);
%     class_result.map=MLRmap;
    % the RW classification 
    figure,imshow(MLR_Probilities);
%     B=[0 1 0;1 1 1;0 1 0];
%     A4=imdilate(MLR_Probilities,B);
%     figure,imshow(A4);
%     se4=strel('disk',5);
%     A4=imerode(A4,se4);
%     figure,imshow(A4);
%     title('MLR probabilites');
%     I1 = load_images( '.\sourceimages\colourset',1);
%     figure,imshow(I1(:,:,:,1))
%     im=img.source; 
%     [rows1,col1,bands1] = size(im);
%  MLR_Probilities=medfilt2(MLR_Probilities,[8 8]);  
    im=img.im;
    im=im';      % 21025*200
    seeds = [train(1,:)];
    labels= [train(2,:)];  
%     img2=reshape(im,[rows1 col1 bands1]); % 145*145*200
    img2=reshape(im,[rows cols bands]); % 145*145*200
    %[no_lines, no_rows, no_bands] = size(img2);
%     if size(img2,2)>300
%         GDimg=mean(img2,3);
%         GDimg=mat2gray(GDimg);
%         [mask,probabilities] = random_walker(GDimg,seeds,labels);
%         RWresult=mask(:);
%     else
%     GDimg= PCA_img(img2,1); % PCA��ά(1ά) 145*145
%     end
%     GDimg=mat2gray(GDimg);  % ��ԭ�����һ��
%     [mask,probabilities] = random_walker(GDimg,seeds,labels); % ������߷���ͼ(mask)���������(probabilities)
%     RWresult=mask(:);       % ���н�������(Lableͼ) 21025*1
%     
   % the ERW optimation     % ��չ��������Ż�
%     p1=p';    % 21025*16
   p1=my_Probilities';    % 21025*16
%     prob=reshape(p1,[rows cols 1]);  % ����ͼ 145*145*16���ĵ�����ÿһ��ĸ���
    prob=reshape(p1,[rows cols classes]);  % ����ͼ 145*145*16���ĵ�����ÿһ��ĸ���
%     gamma=0.1^5; % or 
    gamma = 0.1^5;
    %beta = 0.1^5; 
%     beta=710;
    beta=710;
   [ERWresult,probability] = RWOptimize(im,seeds,labels,beta,prob,gamma,1); % ��չ��������Ż�����ͼ(ERWresult, 1*21025)���������(probability, 145*145*16)
    MLRmap2=reshape(ERWresult,[rows cols]);
    RWOptimize_Probabilies = probability(:,:,1);
    figure,imshow(RWOptimize_Probabilies);
    title('RWOptimize');
    RWOptimize_Probabilies = reshape(RWOptimize_Probabilies,[1,rows*cols]);
    RWOptimize_Probabilies(1,img.light) = 1;
    RWOptimize_Probabilies(1,img.dark) = 0;
    RWOptimize_Probabilies = reshape(RWOptimize_Probabilies,[rows,cols]);
    figure,imshow(RWOptimize_Probabilies);
    title('RWOptimize2');
   %    [seg_results.OA(iter),seg_results.kappa(iter), seg_results.AA(iter),seg_results.CA(iter,:)]= calcError(test(2,:)-1, ERWresult(test(1,:))-1,[1:no_classes]);
%    seg_results.map=ERWresult; % 1*21025 
% Comprasion
% disp(seg_results);
% disp(class_results);
% varargout(1) = {class_results};
% if nargout == 2, varargout(2) = {seg_results};end
return

% %-----------------------------------------------------------------------%
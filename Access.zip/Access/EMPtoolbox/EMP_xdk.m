%%%%%%% EMP %%%%%%%% ...
% This function computes the stacked vector EMP from the features
% of the original Hyperspectral Image.
% 
% INPUT:
% InputImage              = Path of the original image
% OutputImage             = Path of the output image
% InitialSizeOfSE         = Initial size of the radius of SE (dish)
% Step                    = Step of SE (InitialSizeOfSE+Step for each iteration)
% NumberOfOpeningClosing  = Number of Opening/Closing of the MP. The final
%                           dimension will be: (NumberOfOpeningClosing*2+1)*NumberOfBandofPCs = EMPs
% PCA                     = Do you also want the computation of PCA? (true/false). This should be done if you provide the original data as %							input and hence a feature reduction step is required
%
% EXAMPLE:
% EMP('PaviaPCA','PaviaEMP', 1 , 2, 4, true);  
%
% Mattia Pedergnana
% mattia@mett.it
% 05/04/2011
% revised by Xudong Kang at Oct. 2013
% xudong_kang@163.com
%%%%%%%

function OutEMP = EMP_xdk(InputImage, InitialSizeOfSE, Step, NumberOfOpeningClosing, PCA)

if nargin ~= 5
    help EMP_help
    error('You must provide five inputs.');
end
I = InputImage;
if PCA
    PCs= PCA_img(I,4);
else
    PCs = I;
end

[row, col, Bands] = size(PCs);
% WBar = waitbar(0,'Wait.. I am computing the EMP vector for you.. be happy :)');


for i=1:Bands
%     waitbar(i / Bands);
    %Normalization
    TempRE = reshape(PCs(:,:,i), row*col, 1 );
    TempRE = ((TempRE-mean(TempRE))/std(TempRE)+3)*1000/6;
    PCs(:,:,i) = reshape(TempRE, row, col, 1);
    
    tempBand = PCs(:,:,i);
    MP = morpho_multiN(tempBand, InitialSizeOfSE, Step, NumberOfOpeningClosing); 
     if(i ~= 1)
       OutEMP = cat(3, OutEMP, MP);
    else
       OutEMP = MP;    
    end
end

% close(WBar);

%% Write OUT in the same directory of IN
% if WriteInSameDirectory
%     hdr = [InputImage '.hdr'];
%     fullPathAndPath = which(hdr);
%     [pathstr, ~, ~, ~] = fileparts(fullPathAndPath);
%     OutputImage = [pathstr '\' OutputImage];
% end
% enviwriteMURA (OutEMP, OutputImage);

% end


load('IndiaP.mat');
no_classes       = 16;
no_train         = round(1025);
OutEMP = EMP_xdk(img,1,2,4,1);
[no_lines, no_rows, no_bands] = size(OutEMP);

%%%% vectorization
im = ToVector(OutEMP);
im = im';
GroundT=GroundT';
im=double(im);
%%%% construct training and test datasets

%%% random selection
indexes=train_test_random_new(GroundT(2,:),fix(no_train/no_classes),no_train);

%%% get the training-test indexes
train_SL = GroundT(:,indexes);
test_SL = GroundT;
test_SL(:,indexes) = [];

%%% get the training-test samples and labels
train_samples = im(:,train_SL(1,:))';
train_labels= train_SL(2,:)';
test_samples = im(:,test_SL(1,:))';
test_labels = test_SL(2,:)';

%%%% Normalize the training set and original image
[train_samples,M,m] = scale_func(train_samples);
[im] = scale_func(im',M,m);
%train_samples = train_samples';
%train_labels= train_labels';
%%%% Select the paramter for SVM with five-fold cross validation
[Ccv Gcv cv cv_t]=cross_validation_svm(train_samples,train_labels);

%%%% Training using a Gaussian RBF kernel
%%% give the parameters of the SVM (Thanks Pedram for providing the
%%% parameters of the SVM)
parameter=sprintf('-c %f -g %f -m 500 -t 2 -q',Ccv,Gcv); 


%%% Train the SVM
model=svmtrain(train_labels,train_samples,parameter);

%%%% SVM Classification
SVMresult = svmpredict(ones(no_lines*no_rows,1),img,model); 

%%%% Evaluation the performance of the SVM
GroudTest = double(test_labels(:,1));
SVMResultTest = SVMresult(test_SL(1,:),:);
[SVMOA,SVMAA,SVMkappa,SVMCA]=confusion(GroudTest,SVMResultTest)
The files are the MATLAB source code for the two papers "Xudong Kang et al. "Spectral-spatial
 hyperspectral image classification with edge-preserving filtering", 
"Feature extraction of hyperspectral images with image fusion and recursive filtering"
IEEE Trans. Geosci. Remote Sens., 2013.

The codes have not been well organized. Please contact me if you meet any problems.

Email: xudong_kang@163.com & xudong_kang@hnu.edu.cn

The code is based on two toolbox.
1) the SVM toolbox which can be downloaded at: http://www.csie.ntu.edu.tw/~cjlin/libsvm/
2) the Dimension reduction toolbox is available at http://homepage.tudelft.nl/19j49/Matlab_Toolbox_for_Dimensionality_Reduction.html

Note: please ensure the two toolbox have been correctly installed and included into the working space before implementing the demo.
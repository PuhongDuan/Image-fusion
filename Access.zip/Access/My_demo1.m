%%%the MATLAB code for the paper "Image matting for fusion of multi-focus images
%%%in dynamic scenes" Author: Xudong Kang
%%%Donot hesitate to contact me if you meet any problems when implementing
%%%this code.
%%%Author: Xudong Kang;                                                            
%%%Email:xudong_kang@163.com
%%%Homepage:http://xudongkang.weebly.com

%%% Input I: two or more than two multifocus images
%%% Output F: a fused image
%%%% gray image fusion
close all,clear,clc;
I = load_images( '.\sourceimages\colourset',1);    % 8 7 11 12 14 4����    7 6��ԭ����
tic
% F1 = IFM(I);
F1 = MYIFM1(I);
toc
img1=double(I(:,:,:,1));
img2=double(I(:,:,:,2));
result=F1;
r1=Evaluation(img1(:,:,1),img2(:,:,1),result(:,:,1));
r2=Evaluation(img1(:,:,2),img2(:,:,2),result(:,:,2));
r3=Evaluation(img1(:,:,3),img2(:,:,3),result(:,:,3));
r=(r1+r2+r3)./3
% r=r1
% figure,imshow(F);
% figure,imshow(F1);
% %%%% color image fusion
% I = load_images( '.\sourceimages\grayset',1); 
% F = IFM(I);
% figure,imshow(F);
load PaviaU.mat;
x=EMAP(img,'x', false, 'a', [10 15 20], 'd', [50 100 500], 's', 150);

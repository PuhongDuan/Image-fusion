for n=1:7
cand=[0 1 2 5 10 15 20];
i=cand(n);
R1 = ['ASSL_PU_MBT_ssl_',num2str(i)];
R2 = ['SOASSL_PU_MBT_ssl_',num2str(i)];
load (R1)
load (R2)
eval(['X','=',R1]);
eval(['Y','=',R2]);
OA_mean=zeros(1,11);
OA_mean2=OA_mean;
for j=1:10
    OA_mean = OA_mean+(X(1,j).OA);
    OA_mean2=OA_mean2+(Y(1,j).OA);
end
OA_mean=OA_mean./10;
OA_mean= round(OA_mean.*10000)/100;
OA_mean2=OA_mean2./10;
OA_mean2= round(OA_mean2.*10000)/100;
train_numbers=[45:10:145];
% plot(train_numbers,OA_mean);hold on
% surf(train_numbers,OA_mean2);hold on
mat_OA(n,:)=OA_mean2;
end
surf(train_numbers,cand,mat_OA);hold on

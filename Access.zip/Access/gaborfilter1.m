function [ gbout_feature ] = gaborfilter1( I_gray )
% I_gray is the input gray image
% gbout_feature is the Gabor feature
theta = [ pi/10  3*pi/10  5*pi/10   8*pi/10 ];  
x=[1 3 5 7];
lamda=[0.2 1 2];
[m,n]=size(I_gray);

gbout=zeros(m,n,length(theta)*length(x)*length(lamda)); 
num=0;
for i=1:4
    for j=1:4
        for k=1:3
            num=num+1;
            [G, gbout_i]=gaborfilter(I_gray,x(j),x(j),lamda(k),theta(i));
            gbout(:,:,num)=gbout_i;
        end
    end
end
gbout_feature=uint8(gbout);


end

